import { Router } from "express";
import MachiControllers from "../../controllers/task/machi.controllers";
import authMiddleware from "../../middlewares/auth.middleware";

const machiRouter = Router()

machiRouter.post('/',authMiddleware,MachiControllers.store)
machiRouter.get('/',authMiddleware,MachiControllers.index)
machiRouter.get('/:id',authMiddleware,MachiControllers.show)
machiRouter.put('/:id',authMiddleware,MachiControllers.update)
machiRouter.delete('/:id',authMiddleware,MachiControllers.delete)

export default machiRouter